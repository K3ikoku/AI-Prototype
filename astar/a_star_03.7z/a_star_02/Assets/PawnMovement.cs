﻿using UnityEngine;
using System.Collections;

public class PawnMovement : MonoBehaviour {

	void OnMouseUp()
    {
        Debug.Log("click");

    }
}
